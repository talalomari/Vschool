$(function(){
  $('a[rel=lightbox]').lightBox({
    containerResizeSpeed: 500,
    fixedNavigation: true
  });

});