module.exports = {
    secret: "hello world",
    database : "todolist"
}